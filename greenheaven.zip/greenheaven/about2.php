
	
<!--pages-starts-->
	<style>
	.link{
		color:#C00;
		}
	</style>
<body>
<div class="contener">
<div class="row">
					<div class="col-sm-12">
					
						<div  style="color:#000;">
                        <div style="margin:90px 90px 90px 90px;">
                        <h2 align="center">About Green Heaven Nursery</h2><br><br>
                        <p>Green heaven is very oldest Nursery, having celebrated its 365th anniversary in 2014. Our history began in the our century when some farmer were established in Nursery. Green heaven was founded in 1649 and is proud to be recognised today as one of the oldest businesses in the Bangladesh....<br><br>
														
								<h4>Flower plants</h4>

								The flowering plants, also known as angiosperms, Angiospermae or Magnoliophyta, are the most diverse group of land plants, with 416 families, approximately 13,164 known genera and c. 295,383 known species. <a href="https://en.wikipedia.org/wiki/Nursery" class="link">Wikipedia</a><br><br>

								<h4>Friut Plants</h4>

								A fruit tree is a tree which bears fruit that is consumed or used by humans and some animals — all trees that are flowering plants produce fruit, which are the ripened ovaries of flowers containing one or more seeds.<a href="https://en.wikipedia.org/wiki/Nursery" class="link">Wikipedia</a><br><br>
								<h4>Gardening Plants</h4>

								Some nurserie specialize in one phase of the process: propagation, growing out, or retail sale; or in one type of plant: groundcovers, shade <a href="https://en.wikipedia.org/wiki/Nursery" class="link">plants</a>, or rock garden plants. Some produce bulk stock.<br><br>

								<h4>Decoration Plants</h4>

								Even if it’s cold and wet outside, a few beautiful plants and plant pots will mean it’s always summer, somewhere in your home. Plants can create a feeling of peace, and caring for them helps us slow down and appreciate the here and now. Our pots and plants help you bring new colours and textures into your home for nature-inspired updates..<br><br>

								<h4>Medicinal Plants</h4>

								Medicinal plants, medicinal herbs, or simply herbs have been identified and used from prehistoric times. Plants make many chemical compounds for biological functions, including defence against insects, fungi and herbivorous mammals.<a href="https://en.wikipedia.org/wiki/Nursery" class="link"> Wikipedia.</a><br><br>

								<h4>Vegetable Plants</h4>

								Everyday usage, vegetables are certain parts of plants that are consumed by humans as food as part of a savory meal. The term vegetable is somewhat arbitrary<a href="https://en.wikipedia.org/wiki/Nursery" class="link">plants</a>, or rock garden plants. Some produce bulk stock, whether seedlings or <br>                       
														
                        
                            </p>
                         </div>
                       </div>
                     </div>
                  </div>
                  </div>
                        			
				
							

   


	

