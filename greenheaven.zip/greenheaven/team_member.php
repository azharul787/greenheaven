
<!--pages-starts-->
    <div class="container">
       <div class="row">
          <div class="col-sm-12">
                             <h2 align="center">Team Member</h2><br><br><br>
                  <div class="col-sm-3">
                  <img src="images/azharul.jpg" class="img-circle" alt="picture" width="200" height="200"><br><br><br>
                  </div>
                  <div class="col-sm-3">
                  <img src="images/mahmuda.jpg" class="img-circle" alt="picture" width="200" height="200"> 
                  </div>
                  <div class="col-sm-3">
                  <img src="images/afruza.jpg" class="img-circle" alt="picture" width="200" height="200"> 
                  </div>
                  <div class="col-sm-3">
                  <img src="images/tanzin.jpg" class="img-circle" alt="picture" width="200" height="200"> 
                  </div>
                 </div>
            
          <div class="col-sm-12">
                 <div class="col-sm-3">
                 <div class="panel-panel-default" style="background-color:#CCC; padding:50px;">
                 <h5>Md.Azharul Islam</h5><br>
                 <p>Hi I am Md.Azharul Islam , I have Complete my Masters Degree in sociology from National university.present add: Dhaka,Bangladesh.parmanent add:village:Helatola,<br>Upozila:kalaroa,<br>District: Satkhira.Email :azharul787@gmail.com, phone number:01911735608. I am the team leader in this Project.  </p>
                 </div>
                 </div>
                 
                 <div class="col-sm-3">
                 <div class="panel-panel-default" style="background-color:#CCC; padding:50px;">
                  <h5>Mst.Syeda Mahmuda Afrose</h5><br>
                 <p>Hi My name is Mst.Syeda Mahmuda Afrose, Masters in social work.present add and parmanent add :Dhaka bangladesh Email add: afrosenaly@gmail.com, Phone no:01676933669.i am team member this site......<br><br><br> </p>
                 
                 </div>
                 </div>
                 
                 <div class="col-sm-3">
                 <div class="panel-panel-default" style="background-color:#CCC; padding:50px;">
                 <h5>Mst.Afroza Ahmed</h5><br>
                 <p>My name is Afoza Ahmed.Masters on Accounting.Present add: Dhaka,Bangladesh.Email:<br>afojaahmed61@.gamil.com. phone number:0176095898 i am  team member this site.......<br><br><br><br><br><br></p>
                 
                 </div>
                 </div>
                 
                 <div class="col-sm-3">
                 <div class="panel-panel-default" style="background-color:#CCC; padding:50px;">
                 <h5>Mst.Tanjin Akter</h5><br>
                 <p>Hi my name is Tanjin akter.Masters in Economics.present add: Dhaka,Bangladesh.and parmanent add: Rahman nagur,Bogra.Email:<br>tanjinliza3934@gmail.com,<br>Phone no:01755393433.i am team member this site.<br><br><br><br></p>
                
                 </div>
                 </div>
                 
          </div>
        </div>
      </div>
	<!--pages-end-->
<div class="arrivals">
	 <div class="container">	
		 <h2  align="center" style="color:#0C3;">Team Member</h2>
		 <div class="arrival-grids">			 
			 <ul id="flexiselDemo4">
				 <li>
					 <a href="#"><img src="images/azharul.jpg" alt=""/>	
					 <div class="arrival-info">
						 <h4>Md. Azharul Islam</h4>
						 
					 </div>
					 <div class="viw">
						<a href="#"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick View</a>
					 </div>
					 <div class="shrt">
						<a href="#"><span class="glyphicon glyphicon-star" aria-hidden="true"></span>Shortlist</a>
					 </div></a>
				 </li>
				 <li>
					 <a href="#"><img src="images/afruza.jpg" alt=""/>
						<div class="arrival-info">
						 <h4>Afroza Ahmed</h4>
						
					 </div>
					 <div class="viw">
						<a href="#"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick View</a>
					 </div>
					 <div class="shrt">
						<a href="#"><span class="glyphicon glyphicon-star" aria-hidden="true"></span>Shortlist</a>
					 </div></a>
				 </li>
				 <li>
					 <a href="#"><img src="images/mahmuda.jpg" alt=""/>	
						<div class="arrival-info">
						 <h4>Sayeda Mahmuda Afroze</h4>
					 </div>
					 <div class="viw">
						<a href="#"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick View</a>
					 </div>
					 <div class="shrt">
						<a href="#"><span class="glyphicon glyphicon-star" aria-hidden="true"></span>Shortlist</a>
					 </div></a>
				 </li>
				 <li>
				    <a href="#"> <img src="images/tanzin.jpg" alt=""/>	
						<div class="arrival-info">
						 <h4>Mst. Tanjin Akter</h4>
						
					 </div>
					 <div class="viw">
						<a href="#"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick View</a>
					 </div>
					 <div class="shrt">
						<a href="#"><span class="glyphicon glyphicon-star" aria-hidden="true"></span>Shortlist</a>
					 </div></a>
				 </li>
				</ul>
				<script type="text/javascript">
				 $(window).load(function() {			
				  $("#flexiselDemo4").flexisel({
					visibleItems: 4,
					animationSpeed: 1000,
					autoPlay: true,
					autoPlaySpeed: 3000,    		
					pauseOnHover:true,
					enableResponsiveBreakpoints: true,
					responsiveBreakpoints: { 
						portrait: { 
							changePoint:480,
							visibleItems: 1
						}, 
						landscape: { 
							changePoint:640,
							visibleItems: 2
						},
						tablet: { 
							changePoint:768,
							visibleItems: 3
						}
					}
				});
				});
				</script>
				<script type="text/javascript" src="file/js/jquery.flexisel.js"></script>			 
		  </div>
	 </div>
</div>
<!---->
	


	



