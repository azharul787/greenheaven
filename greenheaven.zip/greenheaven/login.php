
<div class="login_sec">
	 <div class="container">
		 <h2>Login</h2>
		 <div class="col-md-6 log">			 
				 <p>Welcome, please enter the folling to continue.</p>
				 <p>If you have previously Login with us, <span>click here</span></p>
				 <form action="login_transfer.php" method="post">
					 <h5>Email:</h5>	
					 <input type="text" name="email" placeholder="Email">
					 <h5>Password:</h5>
					 <input type="password" name="password" placeholder="Password" >					
					 <input type="submit" name="login_submit" value="Login">					 
					  <a class="acount-btn" href="#" class="tablink" onclick="openEvent(event, 'create_account')"  >Create an Account</a>
				 </form>
				 <a href="#">Forgot Password ?</a>
					
		 </div>	
				
		 <div class="clearfix"></div>
	 </div>
</div>
<!---->
