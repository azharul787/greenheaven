
	<div class="row">
		<div class="col-md-12">
			<div class="records_content_contact_message">
				<!-- All Content Will display here -->
			</div>
		</div>
	</div>
	<!-- Custom JS file -->
	<script src="contact/contact_controller.js"></script>	
    