
	<div class="row">
		<div class="col-md-12">
			<h3 class="text-center">Feedback Message</h3><br>
			<div class="records_content_feedback">
			<!-- All Content Will display here -->
			</div>
		</div>
	</div>
	<!-- Custom JS file -->
	<script src="feedback/feedback_controller.js"></script>	
    