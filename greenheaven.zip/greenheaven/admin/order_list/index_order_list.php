
	<div class="row">
		<div class="col-md-12">
			<div class="records_content_order_list">
			<!-- All Content Will display here -->
			</div>
		</div>
	</div>
	<div class="container">
	  <div class="modal fade" id="myModal" role="dialog">
		<div class="modal-dialog">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal">&times;</button>
			  <h4 class="modal-title text-center">Order List Details</h4>
			</div>
			<div class="modal-body">
				<div id="view_order_details"></div>
			  
			</div>
			<div class="modal-footer">
			  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		  </div>
		  
		</div>
	  </div>
	</div>
	<!-- Custom JS file -->
	<script type="text/javascript" src="order_list/order_controller.js"></script>	
	
