<?php

	//$database = new mysqli('sql203.epizy.com','epiz_21162708','LZYTwSO6sGTW','epiz_21162708_greenheaven');
	$database = new mysqli('localhost','root','','green_heaven');
?>