	<div class="well">
		<h1>Stock details</h1>
	This is stock Details Page...This is stock Details Page...This is stock Details Page...This is stock Details Page...This is stock Details Page...
	</div>